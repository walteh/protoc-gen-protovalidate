rootProject.name = "protovalidate"
include("conformance")
